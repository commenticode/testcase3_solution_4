<?php
$session = new CHttpSession;
    $cs = Yii::app()->clientScript;
    //$cs->registerScriptFile(Yii::app()->controller->assetsBase . '/js/combodate.js');
    //$cs->registerScriptFile(Yii::app()->controller->assetsBase . '/js/moment.min.js');

    //this is because below country model become ambigious for name values on Window Server
    $countryList = CHtml::listData(Yii::app()->db->createCommand('select a.* from country a inner join (select distinct name, min(id) as id from country group by name) as b on a.name = b.name and a.id = b.id order by b.id<>13 asc,b.name asc;')->queryAll(),'id', 'name');

    /*$countryList = CHtml::listData(
                                    Country::model()->findAll(array(
                                    "order" => "name asc",
                                    "group" => "name"
                                )), 'id', 'name'
                    );*/
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.2.0/jquery-confirm.min.css">
<link rel="stylesheet" href="<?php echo Yii::app()->controller->assetsBase; ?>/css/jquery-ui.css">

<style>
  td,
  th {
    border: 1px solid;
    text-align: left;
    padding: 8px;

  }

  span.glyphicon.glyphicon-remove {
    position: inherit !important;
    line-height: 12px !important;
  }

  span.glyphicon.glyphicon-remove:before {
    font-size: 14px !important;
    position: inherit !important;
  }

  span.glyphicon.glyphicon-remove:after {
    font-size: 14px !important;
    position: inherit !important;
  }
</style>
<?php
$js = <<< EOJ
function beforeValidate(form) {
        if (form.data('submitObject').hasClass('jsNoValidate'))
		{
			this.validateOnSubmit = false;
			this.beforeValidate = '';
			this.attr('action','preregistration/saveExit');
			form.submit();

			return false;
		}

        return true;
}
EOJ;
Yii::app()->clientScript->registerScript('beforeValidate', $js);
?>
<div class="page-content">
  <?php
    $form=$this->beginWidget('CActiveForm', array(
        'id'=>'asic-personal-form',
        'enableClientValidation'=>true,

        'clientOptions'=>array(
            'validateOnSubmit'=>true,
  			'beforeValidate'=>"js:beforeValidate",
  			'afterValidate'=>'js:asicPiForm'

        ),
        'htmlOptions'=>array(
            'class'=> 'form-comfirm-detail',
        )
    ));

    ?>

  <div class="form-group">
    <?php echo $form->hiddenField($model, 'selected_asic_id' ,
            array('value'=>'')
        ); ?>
  </div>

  <div class="row" id="new_asic_area">

    <div class="col-md-4">
      <label>Personal Details</br></label>
      <br>
      <div class="form-group">
        <?php echo $form->textField($model, 'first_name', array('maxlength' => 50, 'placeholder' => 'First Name' , 'class'=>'form-control ')); ?>
        <?php echo $form->error($model, 'first_name'); ?>
      </div>
      <div class="form-group">
        <?php echo $form->textField($model, 'given_name2', array('maxlength' => 50, 'placeholder' => 'Given Name(optional)' , 'class'=>'form-control ')); ?>
        <?php echo $form->error($model, 'given_name2'); ?>
      </div>
      <div class="form-group">
        <?php echo $form->textField($model, 'given_name3', array('maxlength' => 50, 'placeholder' => 'Given Name(optional)' , 'class'=>'form-control ')); ?>
        <?php echo $form->error($model, 'given_name3'); ?>
      </div>
      <div class="form-group">
        <?php echo $form->textField($model, 'last_name', array('maxlength' => 50, 'placeholder' => 'Surname' , 'class'=>'form-control ')); ?>
        <?php echo $form->error($model, 'last_name'); ?>
      </div>

      <div class="custom-control" style="margin-top: 30px;margin-bottom: 15px;">
        <label class="checkbox" for="asic-info-form_pre1">
          <?php
                  	echo CHtml::checkBox('asic-info-form[pre1]',false,array('class'=>'custom-control-input'));
                  ?>
          <span class="checkbox-style"></span>
          Add a previous name
        </label>
      </div>

      <div id='previousName1' style="display:none;margin-bottom: 15px;">
        <div class="form-group">
          <label>Previous Names 1:</label></br>
          <?php echo $form->textField($model, 'changed_given_name1', array('maxlength' => 50, 'placeholder' => 'First Name(optional)' , 'class'=>'form-control ')); ?>
        </div>
        <div class="form-group">
          <?php echo $form->textField($model, 'changed_given_name2', array('maxlength' => 50, 'placeholder' => 'Given Name(optional)' , 'class'=>'form-control ')); ?>
        </div>
        <div class="form-group">
          <?php echo $form->textField($model, 'changed_given_name3', array('maxlength' => 50, 'placeholder' => 'Given Name(optional)' , 'class'=>'form-control ')); ?>
        </div>
        <div class="form-group">
          <?php echo $form->textField($model, 'changed_last_name1', array('maxlength' => 50, 'placeholder' => 'Surname(optional)' , 'class'=>'form-control ')); ?>
        </div>
        <div class="form-group" style="width:150%;">
          <label>Name Type</label><br>
          <?php
                  echo $form->radioButtonList($model, 'name_type1',array(
                  	'Previous'=>'Previous',
                  	'Alias'=>'Alias',
                  	'Maiden'=>'Maiden',
                  	),array('class' => 'password_requirement form-label','separator'=>'&nbsp','style'=>'display:inline; '));

                  	?>
        </div>

        <div class="custom-control" style="margin-top: 30px; margin-bottom: 15px;">
          <label class="checkbox" for="asic-info-form_pre2">
            <?php
                    	echo CHtml::checkBox('asic-info-form[pre2]',false,array('class'=>'custom-control-input'));
                    ?>
            <span class="checkbox-style"></span>
            Add another previous name
          </label>
        </div>

      </div>

      <div id='previousName2' style="display:none;margin-bottom: 15px;">
        <div class="form-group">
          <label>Previous Names 2:</label></br>
          <?php echo $form->textField($model, 'changed_given_name1_1', array('maxlength' => 50, 'placeholder' => 'First Name(optional)' , 'class'=>'form-control ')); ?>
        </div>
        <div class="form-group">
          <?php echo $form->textField($model, 'changed_given_name2_1', array('maxlength' => 50, 'placeholder' => 'Given Name(optional)' , 'class'=>'form-control ')); ?>
        </div>
        <div class="form-group">
          <?php echo $form->textField($model, 'changed_given_name3_1', array('maxlength' => 50, 'placeholder' => 'Given Name(optional)' , 'class'=>'form-control ')); ?>
        </div>
        <div class="form-group">
          <?php echo $form->textField($model, 'changed_last_name2', array('maxlength' => 50, 'placeholder' => 'Surname(optional)' , 'class'=>'form-control ')); ?>
        </div>
        <div class="form-group" style="width:150%;">
          <label>Name Type</label><br>
          <?php
                  echo $form->radioButtonList($model, 'name_type2',array(
                  	'Previous'=>'Previous',
                  	'Alias'=>'Alias',
                  	'Maiden'=>'Maiden',
                  	),array('class' => 'password_requirement form-label','separator'=>'&nbsp','style'=>'display:inline; margin-left:0px;'));

                  	?>
        </div>
      </div>

      <div class="form-group" style="width:150%;">
        <label>Gender</label>
        &nbsp&nbsp
        <?php
                    echo $form->radioButtonList($model, 'gender',array(
                      'male'=>'Male',
                      'female'=>'Female',
                      'indeterminate'=>'X'
                      ),array('class' => 'password_requirement form-label','separator'=>'&nbsp','style'=>'display:inline; margin-left:20px;'));
                       echo $form->error($model,'gender');
                    ?>
      </div>

      <div class="form-group">
        <?php echo $form->textField($model,'email',array('maxlength' => 50, 'placeholder' => 'Email Address', 'class'=>'form-control ')); ?>
        <?php echo $form->error($model,'email'); ?>
      </div>

      <div class="row form-group">
        <div class="col-xs-12 col-md-12 col-sm-12">
          <?php
                        $this->widget('EDatePicker', array(
                            'model'       => $model,
                            'attribute'   => 'date_of_birth',
                            'mode'        => 'date_of_birth',
        			                 'htmlOptions' => array(
                                      //  'style'    => 'width:280px',
        						                        'class'=>'form-control '
                                    ),
                        ));
                        ?>
          <?php echo $form->error($model,'date_of_birth',array('style' => 'margin-left:0')); ?>
        </div>
      </div>

    </div>

    <div class="col-md-4">
      <label>&nbsp;</br></label>
      <br>
      <div class="form-group">
        <?php

                    echo $form->dropDownList($model, 'birth_country', $countryList, array('empty' => 'Select Country of Birth', 'class'=>'form-control ' , /*'options' => array(Visitor::AUSTRALIA_ID => array('selected' => 'selected'))*/));
                    ?>
        <?php echo $form->error($model, 'birth_country'); ?>
      </div>
      <div class="form-group" id="austate">
        <?php echo $form->dropDownList($model, 'birth_state', Visitor::$AUSTRALIAN_STATES_ASIC, array('empty' => 'Select Birth State', 'class'=>'form-control ')); ?>
      </div>
      <div class="form-group">
        <?php echo $form->textField($model, 'birth_city', array('maxlength' => 50, 'placeholder' => 'Town or City' , 'class'=>'form-control ')); ?>
        <?php echo $form->error($model, 'birth_city'); ?>
      </div>
      <div class="form-group">
        <?php
                    echo $form->dropDownList($model, 'citizenship', $countryList, array('empty' => 'Select Country of Citizenship', 'class'=>'form-control ' , /*'options' => array(Visitor::AUSTRALIA_ID => array('selected' => 'selected'))*/));
                    ?>
        <?php echo $form->error($model, 'citizenship'); ?>

      </div>
      <div class="form-group">
        <?php echo $form->textField($model, 'home_phone', array('maxlength' => 50, 'placeholder' => 'Phone (Home).', 'class'=>'form-control ')); ?>

      </div>
      <div class="form-group">
        <?php echo $form->textField($model, 'work_phone', array('maxlength' => 50, 'placeholder' => 'Phone (Work).', 'class'=>'form-control ')); ?>

      </div>
      <div class="form-group">
        <?php echo $form->textField($model, 'mobile_phone', array('maxlength' => 50, 'placeholder' => 'Phone (Mobile).', 'class'=>'form-control ')); ?>
        <?php echo $form->error($model, 'mobile_phone'); ?>
      </div>
      <div class="form-group" style="width:150%;">
        <label>Preferred method of contact </br></label>
        <br>
        <?php
                  echo $form->radioButtonList($model, 'preferred_contact',array(
                  	'Mobile'=>'Mobile',
                  	'Home'=>'Home phone',
                  	'Work'=>'Work phone',
                  	),array('class' => 'password_requirement form-label','separator'=>'&nbsp','style'=>'display:inline; '));
                  	echo $form->error($model,'preferred_contact');
                  	?>
      </div>
    </div>

    <div class="col-md-4" id="residential">
      <label>Current Residential Address</br></label>
      <div class="form-group">
        <?php
          echo $form->textField($model,'addressline',array('placeHolder'=>'Full Address','class'=>'form-control '));
        ?>
        <?php echo $form->hiddenField($model, 'unit'); ?>
        <?php echo $form->hiddenField($model, 'street_name'); ?>
        <?php echo $form->hiddenField($model, 'street_number'); ?>
        <?php echo $form->hiddenField($model, 'street_type'); ?>
        <?php echo $form->hiddenField($model, 'suburb'); ?>
      </div>
      <div class="row form-group">
        <div class="col-xs-6">
          <?php echo $form->dropDownList($model, 'state', Visitor::$AUSTRALIAN_STATES_ASIC, array('empty' => 'Select State', 'class'=>'form-control ')); ?>
          <?php echo $form->error($model, 'state'); ?>
        </div>
        <div class="col-xs-6">
          <?php echo $form->textField($model, 'postcode', array('maxlength' => 50, 'placeholder' => 'Postcode', 'class'=>'form-control ')); ?>
          <?php echo $form->error($model, 'postcode'); ?>
        </div>
      </div>
      <div class="form-group">
        <?php
                  echo $form->dropDownList($model, 'country', $countryList,
                      array('prompt' => 'Select Country', 'class'=>'form-control ',
                          'options' => array(Visitor::AUSTRALIA_ID => array('selected' => 'selected'))));
                  ?>
        <?php echo $form->error($model, 'country'); ?>
      </div>
      <div class="row form-group">
        <div class="col-xs-12 col-md-12 col-sm-12">
          <?php
                    $this->widget('EDatePicker', array(
                        'model'       => $model,
                        'attribute'   => 'from_date',
                        'mode'        => 'ResidentDates',
                         'htmlOptions' => array(
                                  'placeholder'=>'Resident From Date',
                                      'class'=>'form-control '
                                ),
                    ));
                    ?>
          <?php echo $form->error($model,'from_date',array('style' => 'margin-left:0')); ?>
        </div>
      </div>

      <?php
                if(isset($error_message) && !empty($error_message)){
            ?>

      <div class="row form-group">
        <div class="col-xs-6">
          <?php  echo '<span style="color:red">'.$error_message.'</span>'; ?>
        </div>
      </div>

      <?php } ?>
      <div class="form-group" style="width:150%;">
        <label>Current Postal Address </br></label>
        <br>
        <label>As above?</label>
        <?php
                  echo $form->radioButtonList($model, 'is_postal',array(
                  '1'=>'Yes',
                  '0'=>'No',
                  ),array('class' => 'password_requirement form-label','separator'=>'&nbsp','style'=>'display:inline; margin-left:20px;'));
                  echo $form->error($model,'is_postal');
              ?>
      </div>
      <div id="postaladdress" style="display:none;">

        <label>Current Postal Address</br></label>
        <br>
        <div class="form-group">
          <?php
                        echo $form->textField($model,'addresslinePostal',array('placeHolder'=>'Full Address','class'=>'form-control '));
                      ?>
          <?php echo $form->hiddenField($model, 'postal_unit'); ?>
          <?php echo $form->hiddenField($model, 'postal_street_number'); ?>
          <?php echo $form->hiddenField($model, 'postal_street_name'); ?>
          <?php echo $form->hiddenField($model, 'postal_street_type'); ?>
          <?php echo $form->hiddenField($model, 'postal_suburb'); ?>
        </div>
        <div class="row form-group" style="margin-left: -10px;">
          <div class="col-xs-6">
            <?php echo $form->dropDownList($model, 'postal_state', Visitor::$AUSTRALIAN_STATES, array('empty' => 'Select State', 'class'=>'form-control ')); ?>
            <?php echo $form->error($model, 'postal_state'); ?>
          </div>
          <div class="col-xs-6">
            <?php echo $form->textField($model, 'postal_postcode', array('maxlength' => 50, 'placeholder' => 'Postcode', 'class'=>'form-control ')); ?>
            <?php echo $form->error($model, 'postal_postcode'); ?>
          </div>
        </div>


        <div class="form-group">
          <?php
                      echo $form->dropDownList($model, 'postal_country', $countryList,
                          array('prompt' => 'Select Country', 'class'=>'form-control ',
                              'options' => array(Visitor::AUSTRALIA_ID => array('selected' => 'selected'))));
                      ?>
          <?php echo $form->error($model, 'postal_country'); ?>
        </div>
      </div>
    </div>

  </div>

  <div class="wizard-footer button-wrapper-footer">
    <div class="pull-right">
      <input type='submit' id='sub' class='btn btn-fill btn-success btn-wd btn-sub' name='sub' value='Next' onclick="this.style.display = 'none';" />
      <div style='display:none'>
        <input type='button' id='next' class='btn btn-next btn-fill btn-success btn-wd' name='next' value='Next' />
      </div>
      <input type='button' class='btn btn-finish btn-fill btn-success btn-wd' name='finish' value='Finish' />
    </div>
    <div class="pull-left">
      <input type='button' class='btn btn-previous btn-fill btn-default btn-wd' name='previous' value='Previous' />
    </div>
    <div class="clearfix"></div>
  </div>
</div>
<?php $this->endWidget(); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.2.0/jquery-confirm.min.js"></script>
<script src="<?php echo Yii::app()->controller->assetsBase; ?>/js/jquery-ui.min.js"></script>

<script>
  var ResAddLine;

  function asicPiForm(form, data, hasError) {
    if (!hasError) {
      var $form = $("#asic-personal-form");
      form_data = $form.serialize();
      $.ajax({
        url: "<?php echo Yii::app()->baseUrl; ?>/index.php/prereg/asic/asicPiType",
        type: 'POST',
        data: form_data,
        success: function(d) {

          $('#sub').attr('name', 'next');
          $('#sub').attr('class', 'btn btn-next btn-fill btn-success btn-wd')
          $('#sub').attr('type', 'button');
          $('#next').trigger('click');
        },
        error: function(jqXHR, exception) {
          console.log(exception);
        },
        complete: function() {
          $('.btn-sub').show();
        }
      });
      return false;
    } else {
      $('.btn-sub').show();
    }


  }

  $('#RegistrationAsic_addresslinePostal').autocomplete({
    source: function(request, response) {
      $.ajax({
        type: 'GET',
        url: 'https://api.addressfinder.io/api/au/address/autocomplete',
        dataType: "jsonp",
        data: "key=GV7RM6DNL4TY3QJBEUCX&q=" + request.term,
        success: function(data) {
          var valArray = [];
          //response(data);
          $.each(data.completions, function(i, value) {

            valArray.push(value.full_address);

          });

          response(valArray);
        }
      });
    },
    appendTo: '#postaladdress',

    select: function(event, ui) {
      var current_add = $('#RegistrationAsic_addresslinePostal').val();
      var currentArray = current_add.split(" ");
      ResAddLine = current_add.replace(currentArray[currentArray.length - 1], '');
      ResAddLine = ResAddLine.replace(currentArray[currentArray.length - 2], '');
      $('#RegistrationAsic_postal_postcode').val(currentArray[currentArray.length - 1]);
      $('#RegistrationAsic_postal_state').val(currentArray[currentArray.length - 2].toUpperCase());
    },

    change: function(event, ui) {
      var current_add = $('#RegistrationAsic_addresslinePostal').val();
      var currentArray = current_add.split(" ");
      ResAddLine = current_add.replace(currentArray[currentArray.length - 1], '');
      ResAddLine = ResAddLine.replace(currentArray[currentArray.length - 2], '');
      $('#RegistrationAsic_addresslinePostal').val(ResAddLine);

      $.ajax({
        type: 'GET',
        url: 'https://api.addressfinder.io/api/au/address/cleanse',
        dataType: "json",
        data: "key=GV7RM6DNL4TY3QJBEUCX&q=" + current_add,
        success: function(data) {

          if (data.address.street_number_2 != null)
            $('#RegistrationAsic_postal_street_number').val(data.address.street_number_1 + "-" + data.address.street_number_2);
          else
            $('#RegistrationAsic_postal_street_number').val(data.address.street_number_1);

          if (data.address.unit_identifier != null)
            $('#RegistrationAsic_postal_unit').val(data.address.unit_identifier);

          $('#RegistrationAsic_postal_street_name').val(data.address.street_name);
          $('#RegistrationAsic_postal_street_type').val(data.address.street_type);
          $('#RegistrationAsic_postal_suburb').val(data.address.locality_name);
          $('#RegistrationAsic_postal_state').val(data.address.state_territory);
          $('#RegistrationAsic_postal_postcode').val(data.address.postcode);




        }



      });
    }
  });

  $('#RegistrationAsic_addressline').autocomplete({
    source: function(request, response) {
      $.ajax({
        type: 'GET',
        url: 'https://api.addressfinder.io/api/au/address/autocomplete',
        dataType: "jsonp",
        data: "key=GV7RM6DNL4TY3QJBEUCX&q=" + request.term,
        success: function(data) {
          var valArray = [];
          //response(data);
          $.each(data.completions, function(i, value) {

            valArray.push(value.full_address);

          });

          response(valArray);
        }
      });
    },
    appendTo: '#residential',

    select: function(event, ui) {
      var current_add = $('#RegistrationAsic_addressline').val();
      $.ajax({
        type: 'GET',
        url: 'https://api.addressfinder.io/api/au/address/cleanse',
        dataType: "json",
        data: "key=GV7RM6DNL4TY3QJBEUCX&q=" + current_add,
        success: function(data) {

          if (data.address.street_number_2 != null)
            $('#RegistrationAsic_street_number').val(data.address.street_number_1 + "-" + data.address.street_number_2);
          else
            $('#RegistrationAsic_street_number').val(data.address.street_number_1);

          if (data.address.unit_identifier != null)
            $('#RegistrationAsic_unit').val(data.address.unit_identifier);
          $('#RegistrationAsic_street_name').val(data.address.street_name);
          $('#RegistrationAsic_street_type').val(data.address.street_type);
          $('#RegistrationAsic_suburb').val(data.address.locality_name);
          $('#RegistrationAsic_state').val(data.address.state_territory);
          $('#RegistrationAsic_postcode').val(data.address.postcode);




        }



      });
    },

    change: function(event, ui) {
      var current_add = $('#RegistrationAsic_addressline').val();
      var currentArray = current_add.split(" ");
      ResAddLine = current_add.replace(currentArray[currentArray.length - 1], '');
      ResAddLine = ResAddLine.replace(currentArray[currentArray.length - 2], '');
      $('#RegistrationAsic_addressline').val(ResAddLine);

      $.ajax({
        type: 'GET',
        url: 'https://api.addressfinder.io/api/au/address/cleanse',
        dataType: "json",
        data: "key=GV7RM6DNL4TY3QJBEUCX&q=" + current_add,
        success: function(data) {

          if (data.address.street_number_2 != null)
            $('#RegistrationAsic_street_number').val(data.address.street_number_1 + "-" + data.address.street_number_2);
          else
            $('#RegistrationAsic_street_number').val(data.address.street_number_1);

          if (data.address.unit_identifier != null)
            $('#RegistrationAsic_unit').val(data.address.unit_identifier);

          $('#RegistrationAsic_street_name').val(data.address.street_name);
          $('#RegistrationAsic_street_type').val(data.address.street_type);
          $('#RegistrationAsic_suburb').val(data.address.locality_name);
          $('#RegistrationAsic_state').val(data.address.state_territory);
          $('#RegistrationAsic_postcode').val(data.address.postcode);




        }



      });
    }
  });



  $(document).ready(function() {

    $('#RegistrationAsic_birth_country').on('change', function() {

      if ($(this).val() != '13') {
        //$('#nastate').show();
        $('#austate').hide();
      } else {
        //  $('#nastate').hide();
        $('#austate').show();
      }


    });
    $('#RegistrationAsic_email').val('<?php echo Yii::app()->user->email;?>');
    var action = '<?php echo Yii::app()->controller->action->id;?>';
    if (action == 'savedApplication') {
      if ($('input[name="RegistrationAsic[name_type1]"]:checked').val()) {
        $('#asic-info-form_pre1').trigger('click');
        $('#previousName1').show();
      }
      if ($('input[name="RegistrationAsic[name_type2]"]:checked').val()) {
        $('#asic-info-form_pre2').trigger('click');
        $('#previousName2').show();
      }
      $('#RegistrationAsic_addressline').val('<?php echo $session['
        savedCAddress '];?>');
      if ('<?php if( isset($session['
        savedPAddress '])){echo '
        1 ';}?>' == 1) {
        $('#RegistrationAsic_addresslinePostal').val('<?php echo $session['
          savedPAddress ']; ?>');
      }

    }

    $('#RegistrationAsic_citizenship').on('change', function() {
      if ($('#RegistrationAsic_citizenship').val() == '13') {

        $('#Immigration_is_citizen_0').prop('checked', true);
      } else {

        $('#Immigration_is_citizen_1').prop('checked', true);
        $('#immiinfo').show();
        $('#Immi').show();
        $('#btnSave').show();

      }



    });

    if ($('#RegistrationAsic_changed_given_name1').val() != '') {
      $('#asic-info-form_pre1').prop("checked", true);
      $('#previousName1').show();
      $('#uploadPre').show();
    }
    if ($('#RegistrationAsic_changed_given_name1_1').val() != '') {

      $('#asic-info-form_pre2').prop("checked", true);
      $('#previousName2').show();
    }



    $('#asic-info-form_pre1').on('click', function() {
      $('#previousName1').toggle();

    });
    $('#asic-info-form_pre2').on('click', function() {
      $('#previousName2').toggle();
    });


    $('#Registration_contact_country').on('change', function() {
      var countryId = parseInt($(this).val());
      //Dropdown: id=13,value=Australia
      if (countryId == 13) {
        $("#stateDropdown").show();
        $("#stateTextbox").hide();
        $("#stateTextbox input").prop("disabled", true);
        $("#stateDropdown select").prop("disabled", false);
      } else {
        $("#stateTextbox").show();
        $("#stateDropdown").hide();
        $("#stateDropdown select").prop("disabled", true);
        $("#stateTextbox input").prop("disabled", false);
      }

    });

    $("input[name='RegistrationAsic[is_postal]']").on("click", function(e) {
      var val = $(this).val();
      if (val == 0) {
        $('#postaladdress').show();

      } else {
        $('#postaladdress').hide();
      }
    });





    //lose focus from email and check the already entered email



    //******************************************************************************************************
    //******************************************************************************************************
  });
</script>
